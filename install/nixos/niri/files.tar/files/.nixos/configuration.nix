{ config, pkgs, ... }:

{
  imports = [ /etc/nixos/configuration.nix ];

  # packages
  environment.systemPackages = with pkgs; [
    ghostty
    fastfetch
    git
    eza
    rofi
    swaybg
    waybar
    mako
    libnotify
    wlogout
    pavucontrol
    adwaita-icon-theme
    vanilla-dmz
  ];

  fonts.packages = with pkgs; [
    nerd-fonts.geist-mono
  ];

  programs.zsh = {
    enable = true;
    enableCompletion = true;
    autosuggestions.enable = true;
    syntaxHighlighting.enable = true;
    shellAliases = {
      niu = "sudo -v && clear && fastfetch && nix flake update --flake ~/.nixos && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nis = "sudo -v && clear && fastfetch && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nic = "nano ~/.nixos/configuration.nix";
      nif = "nano ~/.nixos/flake.nix";
      ls = "eza --icons --group-directories-first";
    };
  };
  users.defaultUserShell = pkgs.zsh;
  programs.starship.enable = true;

  programs.firefox.enable = true;
  programs.thunar.enable = true;
  services.devmon.enable = true;

  programs.niri.enable = true;
  services.displayManager.cosmic-greeter.enable = true;

  #hardware.bluetooth.enable = true;
  #services.blueman.enable = true;

  # flakes
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # variables
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
    ELECTRON_OZONE_PLATFORM_HINT = "auto";
  };

  # cleanup
  nix.gc = {
    automatic = true;
    dates = "daily";
    options = "--delete-older-than 2d";
  };

  nix.optimise = {
    automatic = true;
    dates = "weekly";
  };

  # boot
  boot.loader.systemd-boot.configurationLimit = 3;

  #boot.loader.systemd-boot.extraEntries."fedora.conf" = ''
  #    title Fedora
  #    efi /EFI/fedora/shimx64.efi
  #'';

  # kernel
  #boot.kernelPackages = pkgs.cachyosKernels.linuxPackages-cachyos-latest-x86_64-v3; # https://github.com/xddxdd/nix-cachyos-kernel
  nix.settings.substituters = [ "https://attic.xuyh0120.win/lantian" ];
  nix.settings.trusted-public-keys = [ "lantian:EeAUQ+W+6r7EtwnmYjeVwx5kOGEBpjlBfPlzGlTNvHc=" ];

