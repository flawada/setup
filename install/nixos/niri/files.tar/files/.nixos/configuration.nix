{ config, pkgs, ... }:

{
  imports = [ /etc/nixos/configuration.nix ];

  # packages
  environment.systemPackages = with pkgs; [
    ghostty
    fastfetch
    git
    eza
  ];

  programs.zsh = {
    enable = true;
    enableCompletion = true;
    autosuggestions.enable = true;
    syntaxHighlighting.enable = true;
    shellAliases = {
      niu = "clear && fastfetch && nix flake update --flake ~/.nixos && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nis = "clear && fastfetch && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nic = "nano ~/.nixos/configuration.nix";
      nif = "nano ~/.nixos/flake.nix";
      ls = "eza --icons --group-directories-first";
    };
  };
  users.defaultUserShell = pkgs.zsh;
  programs.starship.enable = true;

  programs.firefox.enable = true;

  services.displayManager.cosmic-greeter.enable = true;
  services.desktopManager.cosmic.enable = true;
  environment.cosmic.excludePackages = with pkgs; [
    cosmic-term
    cosmic-reader
  ];
  services.desktopManager.cosmic.showExcludedPkgsWarning = false;

  # flakes
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # variables
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
  };

  # cleanup
  nix.gc = {
    automatic = true;
    dates = "daily";
    options = "--delete-older-than 3d";
  };

  nix.optimise = {
    automatic = true;
    dates = "weekly";
  };

  # boot
  boot.loader.systemd-boot.configurationLimit = 3;

  #boot.loader.systemd-boot.extraEntries."fedora.conf" = ''
  #    title Fedora
  #    efi /EFI/fedora/shimx64.efi
  #'';

  # kernel
  #boot.kernelPackages = pkgs.cachyosKernels.linuxPackages-cachyos-latest-x86_64-v3; # https://github.com/xddxdd/nix-cachyos-kernel
  nix.settings.substituters = [ "https://attic.xuyh0120.win/lantian" ];
  nix.settings.trusted-public-keys = [ "lantian:EeAUQ+W+6r7EtwnmYjeVwx5kOGEBpjlBfPlzGlTNvHc=" ];

