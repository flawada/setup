{ config, pkgs, ... }:

{
  imports = [ /etc/nixos/configuration.nix ];

  # packages
  environment.systemPackages = with pkgs; [
    ghostty
    fastfetch
    git
    eza
  ];

  fonts.packages = with pkgs; [
    nerd-fonts.fira-code
    nerd-fonts.jetbrains-mono
  ];

  programs.starship.enable = true;

  programs.zsh = {
    enable = true;
    enableCompletion = true;
    autosuggestions.enable = true;
    syntaxHighlighting.enable = true;
    shellAliases = {
      niu = "clear && fastfetch && nix flake update --flake ~/.nixos && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nis = "clear && fastfetch && sudo nixos-rebuild switch --impure --flake ~/.nixos && clear";
      nic = "nano ~/.nixos/configuration.nix";
      nif = "nano ~/.nixos/flake.nix";
      ls = "eza --icons --group-directories-first";
    };
  };

  users.defaultUserShell = pkgs.zsh;

  services.displayManager.sddm.enable = true;
  services.desktopManager.plasma6.enable = true;

  programs.firefox.enable = true;

  # flakes
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # variables
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
  };

  # cleanup
  nix.gc = {
    automatic = true;
    dates = "daily";
    options = "--delete-older-than 3d";
  };

  nix.optimise = {
    automatic = true;
    dates = "weekly";
  };

  # boot
  boot.loader.systemd-boot.configurationLimit = 3;

  #boot.loader.systemd-boot.extraEntries."fedora.conf" = ''
  #    title Fedora
  #    efi /EFI/fedora/shimx64.efi
  #'';

  # kernel
  #boot.kernelPackages = pkgs.cachyosKernels.linuxPackages-cachyos-latest-x86_64-v3; # https://github.com/xddxdd/nix-cachyos-kernel
  nix.settings.substituters = [ "https://attic.xuyh0120.win/lantian" ];
  nix.settings.trusted-public-keys = [ "lantian:EeAUQ+W+6r7EtwnmYjeVwx5kOGEBpjlBfPlzGlTNvHc=" ];

