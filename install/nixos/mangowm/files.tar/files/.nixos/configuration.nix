{ config, pkgs, ... }:

{
  imports = [ /etc/nixos/configuration.nix ];

  # packages
  environment.systemPackages = with pkgs; [
    # mangowm
    rofi #application-menu
    swaybg #background
    waybar #taskbar
    wlsunset #gammacontrol
    mako #notification-daemon
    libnotify #notification
    wlogout #logout-menu
    pavucontrol #sound-menu
    adwaita-icon-theme #icons for thunar
    wl-clip-persist #clipboard-storer
    polkit_gnome #auth-agent
    # misc
    ghostty #terminal
    helix #editor. can also use vim/mousepad/nano
    fastfetch #information
    git #for cloning, optional
    eza #better ls
  ];

  fonts.packages = with pkgs; [
    nerd-fonts.geist-mono #font for ghostty
  ];

  programs.zsh = {
    enable = true; #shell
    enableCompletion = true;
    autosuggestions.enable = true;
    syntaxHighlighting.enable = true;
    shellAliases = {
      niu = "sudo -v && clear && fastfetch && nix flake update --flake ~/.nixos && sudo nixos-rebuild switch --impure --flake ~/.nixos";
      nis = "sudo -v && clear && fastfetch && sudo nixos-rebuild switch --impure --flake ~/.nixos";
      nic = "hx ~/.nixos/configuration.nix";
      nif = "hx ~/.nixos/flake.nix";
      ls = "eza --icons --group-directories-first";
      la = "ls -la";
    };
  };
  users.defaultUserShell = pkgs.zsh;
  programs.starship.enable = true; #customizable prompt for zsh

  programs.firefox.enable = true; #browser
  programs.thunar.enable = true; #file-manager
  services.devmon.enable = true; #automatic mount

  programs.mango.enable = true; #window-manager
  services.greetd = {
    enable = true; #login-manager & menu
    settings = {
      default_session = {
        command = "${pkgs.tuigreet}/bin/tuigreet --cmd mango";
        user = "greeter";
      };
    };
  };

  
  #hardware.bluetooth.enable = true; #bluetooth
  #services.blueman.enable = true; #bluetooth

  # flakes
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # variables
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
    ELECTRON_OZONE_PLATFORM_HINT = "auto";
  };

  # cleanup
  nix.gc = {
    automatic = true;
    dates = "daily";
    options = "--delete-older-than 2d";
  };

  nix.optimise = {
    automatic = true;
    dates = "daily";
  };

  # boot
  boot.loader.systemd-boot.configurationLimit = 3;

  # kernel
  #boot.kernelPackages = pkgs.cachyosKernels.linuxPackages-cachyos-latest-x86_64-v3; # https://github.com/xddxdd/nix-cachyos-kernel
  nix.settings.substituters = [ "https://cache.lantian.pub/lantian" ];
  nix.settings.trusted-public-keys = [ "lantian:WVGO7vsRMSEN+h7Lp7kv6SAmrkEXgUGbbXm7jMDjBuQ=" ];
  
