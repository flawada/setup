{
  inputs = {
    nixpkgs.url = "nixpkgs/nixos-unstable";
    nix-cachyos-kernel.url = "github:xddxdd/nix-cachyos-kernel/release";
    mangowm = { url = "github:mangowm/mango"; inputs.nixpkgs.follows = "nixpkgs"; };
  };

  outputs = { self, nixpkgs, nix-cachyos-kernel, mangowm }: {
    nixosConfigurations.HOSTNAME = nixpkgs.lib.nixosSystem {
      modules = [
        {
          nixpkgs.overlays = [ nix-cachyos-kernel.overlays.pinned ];
        }
        ./configuration.nix
      ];
    };
  };

}
