#!/bin/bash

layouts=(
  "Tile:tile"
  "Scroller:scroller"
  "Monocle:monocle"
  "Grid:grid"
  "Deck:deck"
  "Fair:fair"
  "Dwindle:dwindle"
  "Center Tile:center_tile"
  "Vertical Tile:vertical_tile"
  "Right Tile:right_tile"
  "Vertical Scroller:vertical_scroller"
  "Vertical Grid:vertical_grid"
  "Vertical Deck:vertical_deck"
  "Vertical Fair:vertical_fair"
)

choice=$(
  printf '%s\n' "${layouts[@]%%:*}" |
    rofi -config ~/.config/mango/rofi/config.rasi -show drun -dmenu -i -p "Layout:"
) || exit 0



for item in "${layouts[@]}"; do
  if [[ "${item%%:*}" == "$choice" ]]; then
    mmsg dispatch "setlayout,${item#*:}"
    exit
  fi
done
