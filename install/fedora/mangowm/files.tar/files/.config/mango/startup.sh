#!/bin/bash

export XDG_CURRENT_DESKTOP=wlroots
export XDG_SESSION_TYPE=wayland
export XDG_SESSION_DESKTOP=mango

dbus-update-activation-environment --systemd DISPLAY WAYLAND_DISPLAY XDG_CURRENT_DESKTOP XDG_SESSION_TYPE XDG_SESSION_DESKTOP

# polkit (auth)
if ! pgrep -x "xfce-polkit" >/dev/null; then
  /usr/libexec/xfce-polkit &
fi

# lock
gtklock -b ~/.config/mango/wallpaper -T 60 &

# fast launch GTK/Qt apps
fc-cache -f &
gtk-update-icon-cache -q &

# theme
gsettings set org.gnome.desktop.interface gtk-theme 'Graphite-Dark'
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'
#gsettings set org.gnome.desktop.interface cursor-theme ''
#gsettings set org.gnome.desktop.interface icon-theme ''
#gsettings set org.gnome.desktop.interface font-name ''

# night light
wlsunset -T 3501 -t 3500 &

# wallpaper
swaybg -i ~/.config/mango/wallpaper &

# bar
waybar -c ~/.config/mango/waybar/config.jsonc -s ~/.config/mango/waybar/style.css &

# notifications daemon
mako -c ~/.config/mango/mako/config &

# keep clipboard content
wl-clip-persist --clipboard regular --reconnect-tries 0 &

# clipboard content manager
#wl-paste --type text --watch cliphist store &

# autostart applications
#helium &
#ghostty -e hx &
notify-send -u critical "Terminal Shortcuts" "din [package]: install a package\ndrm [package]: remove a package\ndup: update\n"
notify-send -u critical "Waybar(Taskbar)" "Right and left click on buttons toggle actions"
notify-send -u critical "Basic Keybinds" "SUPER+R: Terminal\nSUPER+Q: Quit Window\nSUPER+W: Browser\nSUPER+E: File manager\n"
notify-send -u critical "Settings" "change your monitor refresh rate and other settings in ~/.config/mango/config.toml"
head -n -5 ~/.config/mango/startup.sh > file.tmp && mv file.tmp ~/.config/mango/startup.sh
